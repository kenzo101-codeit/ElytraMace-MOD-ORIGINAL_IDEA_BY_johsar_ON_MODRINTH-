package net.minecraft.client.gui.components;

import java.util.function.Supplier;
import javax.annotation.Nullable;
import net.minecraft.client.gui.ComponentPath;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.gui.navigation.FocusNavigationEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.sounds.SoundManager;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.PlayerModelType;
import net.minecraft.world.entity.player.PlayerSkin;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class PlayerSkinWidget extends AbstractWidget {
    private static final float MODEL_HEIGHT = 2.125F;
    private static final float FIT_SCALE = 0.97F;
    private static final float ROTATION_SENSITIVITY = 2.5F;
    private static final float DEFAULT_ROTATION_X = -5.0F;
    private static final float DEFAULT_ROTATION_Y = 30.0F;
    private static final float ROTATION_X_LIMIT = 50.0F;
    private final PlayerModel wideModel;
    private final PlayerModel slimModel;
    private final Supplier<PlayerSkin> skin;
    private float rotationX = -5.0F;
    private float rotationY = 30.0F;

    public PlayerSkinWidget(int width, int height, EntityModelSet model, Supplier<PlayerSkin> skin) {
        super(0, 0, width, height, CommonComponents.EMPTY);
        this.wideModel = new PlayerModel(model.bakeLayer(ModelLayers.PLAYER), false);
        this.slimModel = new PlayerModel(model.bakeLayer(ModelLayers.PLAYER_SLIM), true);
        this.skin = skin;
    }

    @Override
    protected void renderWidget(GuiGraphics p_299897_, int p_299826_, int p_300009_, float p_299921_) {
        float f = 0.97F * this.getHeight() / 2.125F;
        float f1 = -1.0625F;
        PlayerSkin playerskin = this.skin.get();
        PlayerModel playermodel = playerskin.model() == PlayerModelType.SLIM ? this.slimModel : this.wideModel;
        p_299897_.submitSkinRenderState(
            playermodel,
            playerskin.body().texturePath(),
            f,
            this.rotationX,
            this.rotationY,
            -1.0625F,
            this.getX(),
            this.getY(),
            this.getRight(),
            this.getBottom()
        );
    }

    @Override
    protected void onDrag(MouseButtonEvent p_447054_, double p_299829_, double p_299876_) {
        this.rotationX = Mth.clamp(this.rotationX - (float)p_299876_ * 2.5F, -50.0F, 50.0F);
        this.rotationY += (float)p_299829_ * 2.5F;
    }

    @Override
    public void playDownSound(SoundManager p_299880_) {
    }

    @Override
    protected void updateWidgetNarration(NarrationElementOutput p_299955_) {
    }

    @Nullable
    @Override
    public ComponentPath nextFocusPath(FocusNavigationEvent p_299934_) {
        return null;
    }
}
