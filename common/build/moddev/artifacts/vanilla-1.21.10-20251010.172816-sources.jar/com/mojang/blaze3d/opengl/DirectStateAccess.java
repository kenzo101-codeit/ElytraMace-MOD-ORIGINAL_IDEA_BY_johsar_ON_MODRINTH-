package com.mojang.blaze3d.opengl;

import com.mojang.blaze3d.GraphicsWorkarounds;
import java.nio.ByteBuffer;
import java.util.Set;
import javax.annotation.Nullable;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.lwjgl.opengl.ARBBufferStorage;
import org.lwjgl.opengl.ARBDirectStateAccess;
import org.lwjgl.opengl.GL30;
import org.lwjgl.opengl.GL31;
import org.lwjgl.opengl.GLCapabilities;

@OnlyIn(Dist.CLIENT)
public abstract class DirectStateAccess {
    public static DirectStateAccess create(GLCapabilities capabilities, Set<String> enabledExtensions, GraphicsWorkarounds workarounds) {
        if (capabilities.GL_ARB_direct_state_access && GlDevice.USE_GL_ARB_direct_state_access && !workarounds.isGlOnDx12()) {
            enabledExtensions.add("GL_ARB_direct_state_access");
            return new DirectStateAccess.Core();
        } else {
            return new DirectStateAccess.Emulated();
        }
    }

    abstract int createBuffer();

    abstract void bufferData(int buffer, long size, int usage);

    abstract void bufferData(int buffer, ByteBuffer data, int usage);

    abstract void bufferSubData(int buffer, int offset, ByteBuffer data, int usage);

    abstract void bufferStorage(int buffer, long size, int usage);

    abstract void bufferStorage(int buffer, ByteBuffer data, int usage);

    @Nullable
    abstract ByteBuffer mapBufferRange(int buffer, int offset, int length, int access, int usage);

    abstract void unmapBuffer(int buffer, int usage);

    abstract int createFrameBufferObject();

    abstract void bindFrameBufferTextures(int frameBuffer, int colorTexture, int depthTexture, int level, int target);

    abstract void blitFrameBuffers(
        int readFrameBuffer,
        int drawFrameBuffer,
        int srcX0,
        int srcY0,
        int srcX1,
        int srcY1,
        int destX0,
        int destY0,
        int destX1,
        int destY1,
        int mask,
        int filter
    );

    abstract void flushMappedBufferRange(int buffer, int offset, int length, int usage);

    abstract void copyBufferSubData(int readBuffer, int writeBuffer, int readOffset, int writeOffset, int size);

    @OnlyIn(Dist.CLIENT)
    static class Core extends DirectStateAccess {
        @Override
        int createBuffer() {
            GlStateManager.incrementTrackedBuffers();
            return ARBDirectStateAccess.glCreateBuffers();
        }

        @Override
        void bufferData(int p_418123_, long p_418371_, int p_418160_) {
            ARBDirectStateAccess.glNamedBufferData(p_418123_, p_418371_, GlConst.bufferUsageToGlEnum(p_418160_));
        }

        @Override
        void bufferData(int p_418280_, ByteBuffer p_418007_, int p_418178_) {
            ARBDirectStateAccess.glNamedBufferData(p_418280_, p_418007_, GlConst.bufferUsageToGlEnum(p_418178_));
        }

        @Override
        void bufferSubData(int p_418076_, int p_418299_, ByteBuffer p_418117_, int p_434651_) {
            ARBDirectStateAccess.glNamedBufferSubData(p_418076_, (long)p_418299_, p_418117_);
        }

        @Override
        void bufferStorage(int p_418428_, long p_418019_, int p_418289_) {
            ARBDirectStateAccess.glNamedBufferStorage(p_418428_, p_418019_, GlConst.bufferUsageToGlFlag(p_418289_));
        }

        @Override
        void bufferStorage(int p_418345_, ByteBuffer p_418031_, int p_418465_) {
            ARBDirectStateAccess.glNamedBufferStorage(p_418345_, p_418031_, GlConst.bufferUsageToGlFlag(p_418465_));
        }

        @Nullable
        @Override
        ByteBuffer mapBufferRange(int p_418027_, int p_418408_, int p_418310_, int p_418214_, int p_433284_) {
            return ARBDirectStateAccess.glMapNamedBufferRange(p_418027_, p_418408_, p_418310_, p_418214_);
        }

        @Override
        void unmapBuffer(int p_418046_, int p_433042_) {
            ARBDirectStateAccess.glUnmapNamedBuffer(p_418046_);
        }

        @Override
        public int createFrameBufferObject() {
            return ARBDirectStateAccess.glCreateFramebuffers();
        }

        @Override
        public void bindFrameBufferTextures(int p_412474_, int p_412101_, int p_412181_, int p_412742_, int p_412591_) {
            ARBDirectStateAccess.glNamedFramebufferTexture(p_412474_, 36064, p_412101_, p_412742_);
            ARBDirectStateAccess.glNamedFramebufferTexture(p_412474_, 36096, p_412181_, p_412742_);
            if (p_412591_ != 0) {
                GlStateManager._glBindFramebuffer(p_412591_, p_412474_);
            }
        }

        @Override
        public void blitFrameBuffers(
            int p_412346_,
            int p_412174_,
            int p_412752_,
            int p_412365_,
            int p_412477_,
            int p_412615_,
            int p_412700_,
            int p_412178_,
            int p_412260_,
            int p_412584_,
            int p_412685_,
            int p_412482_
        ) {
            ARBDirectStateAccess.glBlitNamedFramebuffer(
                p_412346_, p_412174_, p_412752_, p_412365_, p_412477_, p_412615_, p_412700_, p_412178_, p_412260_, p_412584_, p_412685_, p_412482_
            );
        }

        @Override
        void flushMappedBufferRange(int p_418135_, int p_418262_, int p_418080_, int p_435688_) {
            ARBDirectStateAccess.glFlushMappedNamedBufferRange(p_418135_, p_418262_, p_418080_);
        }

        @Override
        void copyBufferSubData(int p_428836_, int p_428841_, int p_428817_, int p_428818_, int p_428819_) {
            ARBDirectStateAccess.glCopyNamedBufferSubData(p_428836_, p_428841_, p_428817_, p_428818_, p_428819_);
        }
    }

    @OnlyIn(Dist.CLIENT)
    static class Emulated extends DirectStateAccess {
        private int selectBufferBindTarget(int usage) {
            if ((usage & 32) != 0) {
                return 34962;
            } else if ((usage & 64) != 0) {
                return 34963;
            } else {
                return (usage & 128) != 0 ? 35345 : 36663;
            }
        }

        @Override
        int createBuffer() {
            return GlStateManager._glGenBuffers();
        }

        @Override
        void bufferData(int p_418415_, long p_418240_, int p_418204_) {
            int i = this.selectBufferBindTarget(p_418204_);
            GlStateManager._glBindBuffer(i, p_418415_);
            GlStateManager._glBufferData(i, p_418240_, GlConst.bufferUsageToGlEnum(p_418204_));
            GlStateManager._glBindBuffer(i, 0);
        }

        @Override
        void bufferData(int p_418504_, ByteBuffer p_418319_, int p_418033_) {
            int i = this.selectBufferBindTarget(p_418033_);
            GlStateManager._glBindBuffer(i, p_418504_);
            GlStateManager._glBufferData(i, p_418319_, GlConst.bufferUsageToGlEnum(p_418033_));
            GlStateManager._glBindBuffer(i, 0);
        }

        @Override
        void bufferSubData(int p_418332_, int p_418165_, ByteBuffer p_418268_, int p_433134_) {
            int i = this.selectBufferBindTarget(p_433134_);
            GlStateManager._glBindBuffer(i, p_418332_);
            GlStateManager._glBufferSubData(i, p_418165_, p_418268_);
            GlStateManager._glBindBuffer(i, 0);
        }

        @Override
        void bufferStorage(int p_418279_, long p_418194_, int p_418045_) {
            int i = this.selectBufferBindTarget(p_418045_);
            GlStateManager._glBindBuffer(i, p_418279_);
            ARBBufferStorage.glBufferStorage(i, p_418194_, GlConst.bufferUsageToGlFlag(p_418045_));
            GlStateManager._glBindBuffer(i, 0);
        }

        @Override
        void bufferStorage(int p_418284_, ByteBuffer p_418011_, int p_418406_) {
            int i = this.selectBufferBindTarget(p_418406_);
            GlStateManager._glBindBuffer(i, p_418284_);
            ARBBufferStorage.glBufferStorage(i, p_418011_, GlConst.bufferUsageToGlFlag(p_418406_));
            GlStateManager._glBindBuffer(i, 0);
        }

        @Nullable
        @Override
        ByteBuffer mapBufferRange(int p_418226_, int p_418017_, int p_418092_, int p_418512_, int p_435186_) {
            int i = this.selectBufferBindTarget(p_435186_);
            GlStateManager._glBindBuffer(i, p_418226_);
            ByteBuffer bytebuffer = GlStateManager._glMapBufferRange(i, p_418017_, p_418092_, p_418512_);
            GlStateManager._glBindBuffer(i, 0);
            return bytebuffer;
        }

        @Override
        void unmapBuffer(int p_418235_, int p_433066_) {
            int i = this.selectBufferBindTarget(p_433066_);
            GlStateManager._glBindBuffer(i, p_418235_);
            GlStateManager._glUnmapBuffer(i);
            GlStateManager._glBindBuffer(i, 0);
        }

        @Override
        void flushMappedBufferRange(int p_418330_, int p_418325_, int p_418530_, int p_435588_) {
            int i = this.selectBufferBindTarget(p_435588_);
            GlStateManager._glBindBuffer(i, p_418330_);
            GL30.glFlushMappedBufferRange(i, p_418325_, p_418530_);
            GlStateManager._glBindBuffer(i, 0);
        }

        @Override
        void copyBufferSubData(int p_428853_, int p_428827_, int p_428852_, int p_428847_, int p_428825_) {
            GlStateManager._glBindBuffer(36662, p_428853_);
            GlStateManager._glBindBuffer(36663, p_428827_);
            GL31.glCopyBufferSubData(36662, 36663, p_428852_, p_428847_, p_428825_);
            GlStateManager._glBindBuffer(36662, 0);
            GlStateManager._glBindBuffer(36663, 0);
        }

        @Override
        public int createFrameBufferObject() {
            return GlStateManager.glGenFramebuffers();
        }

        @Override
        public void bindFrameBufferTextures(int p_412192_, int p_412614_, int p_412332_, int p_412295_, int p_412775_) {
            int i = p_412775_ == 0 ? '\u8ca9' : p_412775_;
            int j = GlStateManager.getFrameBuffer(i);
            GlStateManager._glBindFramebuffer(i, p_412192_);
            GlStateManager._glFramebufferTexture2D(i, 36064, 3553, p_412614_, p_412295_);
            GlStateManager._glFramebufferTexture2D(i, 36096, 3553, p_412332_, p_412295_);
            if (p_412775_ == 0) {
                GlStateManager._glBindFramebuffer(i, j);
            }
        }

        @Override
        public void blitFrameBuffers(
            int p_412705_,
            int p_412256_,
            int p_412077_,
            int p_412762_,
            int p_412738_,
            int p_412701_,
            int p_412455_,
            int p_412525_,
            int p_412252_,
            int p_412684_,
            int p_412520_,
            int p_412585_
        ) {
            int i = GlStateManager.getFrameBuffer(36008);
            int j = GlStateManager.getFrameBuffer(36009);
            GlStateManager._glBindFramebuffer(36008, p_412705_);
            GlStateManager._glBindFramebuffer(36009, p_412256_);
            GlStateManager._glBlitFrameBuffer(p_412077_, p_412762_, p_412738_, p_412701_, p_412455_, p_412525_, p_412252_, p_412684_, p_412520_, p_412585_);
            GlStateManager._glBindFramebuffer(36008, i);
            GlStateManager._glBindFramebuffer(36009, j);
        }
    }
}
