package net.minecraft.client;

import com.google.common.collect.Maps;
import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.blaze3d.platform.Window;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Supplier;
import javax.annotation.Nullable;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.resources.language.I18n;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class KeyMapping implements Comparable<KeyMapping> {
    private static final Map<String, KeyMapping> ALL = Maps.newHashMap();
    private static final Map<InputConstants.Key, List<KeyMapping>> MAP = Maps.newHashMap();
    private final String name;
    private final InputConstants.Key defaultKey;
    private final KeyMapping.Category category;
    protected InputConstants.Key key;
    private boolean isDown;
    private int clickCount;

    public static void click(InputConstants.Key key) {
        forAllKeyMappings(key, p_445128_ -> p_445128_.clickCount++);
    }

    public static void set(InputConstants.Key key, boolean held) {
        forAllKeyMappings(key, p_445126_ -> p_445126_.setDown(held));
    }

    private static void forAllKeyMappings(InputConstants.Key key, Consumer<KeyMapping> action) {
        List<KeyMapping> list = MAP.get(key);
        if (list != null && !list.isEmpty()) {
            for (KeyMapping keymapping : list) {
                action.accept(keymapping);
            }
        }
    }

    public static void setAll() {
        Window window = Minecraft.getInstance().getWindow();

        for (KeyMapping keymapping : ALL.values()) {
            if (keymapping.shouldSetOnIngameFocus()) {
                keymapping.setDown(InputConstants.isKeyDown(window, keymapping.key.getValue()));
            }
        }
    }

    public static void releaseAll() {
        for (KeyMapping keymapping : ALL.values()) {
            keymapping.release();
        }
    }

    public static void restoreToggleStatesOnScreenClosed() {
        for (KeyMapping keymapping : ALL.values()) {
            if (keymapping instanceof ToggleKeyMapping togglekeymapping && togglekeymapping.shouldRestoreStateOnScreenClosed()) {
                togglekeymapping.setDown(true);
            }
        }
    }

    public static void resetToggleKeys() {
        for (KeyMapping keymapping : ALL.values()) {
            if (keymapping instanceof ToggleKeyMapping togglekeymapping) {
                togglekeymapping.reset();
            }
        }
    }

    public static void resetMapping() {
        MAP.clear();

        for (KeyMapping keymapping : ALL.values()) {
            keymapping.registerMapping(keymapping.key);
        }
    }

    public KeyMapping(String name, int key, KeyMapping.Category category) {
        this(name, InputConstants.Type.KEYSYM, key, category);
    }

    public KeyMapping(String name, InputConstants.Type type, int key, KeyMapping.Category category) {
        this.name = name;
        this.key = type.getOrCreate(key);
        this.defaultKey = this.key;
        this.category = category;
        ALL.put(name, this);
        this.registerMapping(this.key);
    }

    public boolean isDown() {
        return this.isDown;
    }

    public KeyMapping.Category getCategory() {
        return this.category;
    }

    public boolean consumeClick() {
        if (this.clickCount == 0) {
            return false;
        } else {
            this.clickCount--;
            return true;
        }
    }

    protected void release() {
        this.clickCount = 0;
        this.setDown(false);
    }

    protected boolean shouldSetOnIngameFocus() {
        return this.key.getType() == InputConstants.Type.KEYSYM && this.key.getValue() != InputConstants.UNKNOWN.getValue();
    }

    public String getName() {
        return this.name;
    }

    public InputConstants.Key getDefaultKey() {
        return this.defaultKey;
    }

    /**
     * Binds a new KeyCode to this
     */
    public void setKey(InputConstants.Key key) {
        this.key = key;
    }

    public int compareTo(KeyMapping other) {
        return this.category == other.category
            ? I18n.get(this.name).compareTo(I18n.get(other.name))
            : Integer.compare(KeyMapping.Category.SORT_ORDER.indexOf(this.category), KeyMapping.Category.SORT_ORDER.indexOf(other.category));
    }

    /**
     * Returns a supplier which gets a keybind's current binding (eg, <code>key.forward</code> returns <samp>W</samp> by default), or the keybind's name if no such keybind exists (eg, <code>key.invalid</code> returns <samp>key.invalid</samp>)
     */
    public static Supplier<Component> createNameSupplier(String key) {
        KeyMapping keymapping = ALL.get(key);
        return keymapping == null ? () -> Component.translatable(key) : keymapping::getTranslatedKeyMessage;
    }

    /**
     * Returns {@code true} if the supplied {@code KeyMapping} conflicts with this
     */
    public boolean same(KeyMapping binding) {
        return this.key.equals(binding.key);
    }

    public boolean isUnbound() {
        return this.key.equals(InputConstants.UNKNOWN);
    }

    public boolean matches(KeyEvent event) {
        return event.key() == InputConstants.UNKNOWN.getValue()
            ? this.key.getType() == InputConstants.Type.SCANCODE && this.key.getValue() == event.scancode()
            : this.key.getType() == InputConstants.Type.KEYSYM && this.key.getValue() == event.key();
    }

    public boolean matchesMouse(MouseButtonEvent event) {
        return this.key.getType() == InputConstants.Type.MOUSE && this.key.getValue() == event.button();
    }

    public Component getTranslatedKeyMessage() {
        return this.key.getDisplayName();
    }

    public boolean isDefault() {
        return this.key.equals(this.defaultKey);
    }

    public String saveString() {
        return this.key.getName();
    }

    public void setDown(boolean value) {
        this.isDown = value;
    }

    private void registerMapping(InputConstants.Key key) {
        MAP.computeIfAbsent(key, p_445127_ -> new ArrayList<>()).add(this);
    }

    @Nullable
    public static KeyMapping get(String name) {
        return ALL.get(name);
    }

    @OnlyIn(Dist.CLIENT)
    public record Category(ResourceLocation id) {
        static final List<KeyMapping.Category> SORT_ORDER = new ArrayList<>();
        public static final KeyMapping.Category MOVEMENT = register("movement");
        public static final KeyMapping.Category MISC = register("misc");
        public static final KeyMapping.Category MULTIPLAYER = register("multiplayer");
        public static final KeyMapping.Category GAMEPLAY = register("gameplay");
        public static final KeyMapping.Category INVENTORY = register("inventory");
        public static final KeyMapping.Category CREATIVE = register("creative");
        public static final KeyMapping.Category SPECTATOR = register("spectator");

        private static KeyMapping.Category register(String name) {
            return register(ResourceLocation.withDefaultNamespace(name));
        }

        public static KeyMapping.Category register(ResourceLocation location) {
            KeyMapping.Category keymapping$category = new KeyMapping.Category(location);
            if (SORT_ORDER.contains(keymapping$category)) {
                throw new IllegalArgumentException(String.format(Locale.ROOT, "Category '%s' is already registered.", location));
            } else {
                SORT_ORDER.add(keymapping$category);
                return keymapping$category;
            }
        }

        public Component label() {
            return Component.translatable(this.id.toLanguageKey("key.category"));
        }
    }
}
